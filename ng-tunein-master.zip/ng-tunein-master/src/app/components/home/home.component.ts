import { Component, OnInit} from '@angular/core';


@Component({
  selector: '[appHome]',
  templateUrl:'./home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

 

}
